package com.retailstore.repository;

import com.retailstore.model.UserDetails;

public class UserDetailsRepositoryCustomImpl implements IUserDetailsRepositoryCustom  {

	@Override
	public UserDetails findUser(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
