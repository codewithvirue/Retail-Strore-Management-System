package com.retailstore.service;

import com.retailstore.model.Order;

public interface IOrderService {
	public void addStore(Order order_id);
	public void addStore(long user_id);

}
