/*
 * package com.retailstore.service;
 * 
 * import com.retailstore.model.Products;
 * 
 * public interface ProductService {
 * 
 * 
 * public void addProducts( Products product ); public void
 * updateProducts(Products product ); public void searchProducts(Products
 * product ); public void deleteProducts(long products_id);
 * 
 * 
 * }
 */